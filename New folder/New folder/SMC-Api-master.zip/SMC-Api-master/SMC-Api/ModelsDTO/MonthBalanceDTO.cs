﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SMC_Api.ModelsDTO
{
    public class MonthBalanceDTO
    {
        public int Income { get; set; }
        public int Outcome { get; set; }
        

    }
}