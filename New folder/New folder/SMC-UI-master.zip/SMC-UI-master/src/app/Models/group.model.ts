export class Group {
    ID: number;
    Name: string;
    NameAr: string;
    Description : string;
    DescriptionAr : string;
    image:any;
    IsActive : boolean;
}