export class Role {
    Id : number;
    Name : string;
}