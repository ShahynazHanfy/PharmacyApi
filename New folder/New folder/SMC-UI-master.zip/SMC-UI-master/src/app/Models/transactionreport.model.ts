
export class TransactionReport {
    fromOrder : Date ;
    toOrder : Date;
    Types : number[];
    StoreId : number ;
}