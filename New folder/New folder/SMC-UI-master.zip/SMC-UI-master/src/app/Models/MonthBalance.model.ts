
export class MonthBalance
{
    Income : number;
    Outcome : number;
}