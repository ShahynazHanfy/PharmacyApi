
export class Employee
{
    ID : number;
    Name : string;
    Department : string;
}