export class OrderType {
    ID: number;
    Name: string;
    NameAr: string;
    ProcessType : boolean;
    IsActive : boolean;
}