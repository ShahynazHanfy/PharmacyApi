export class Store {
    ID: number;
    Name: string;
    Address : string;
    AddressAr : string;
    // Location : string;
    Area : number;
    Telephone: number;
    StockKeeperId:number;
    Remarks: string;
    image:any;
   
}