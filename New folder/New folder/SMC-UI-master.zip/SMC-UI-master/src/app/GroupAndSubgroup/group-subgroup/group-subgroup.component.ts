import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-group-subgroup',
  templateUrl: './group-subgroup.component.html',
  styleUrls: ['./group-subgroup.component.css']
})
export class GroupSubgroupComponent implements OnInit {

  groupId = 0;
  constructor() { }

  ngOnInit() {
  }

}
